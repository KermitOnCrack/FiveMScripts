https://forum.cfx.re/t/dpclothing-1-0-0-clothing-variations-and-toggles-gloves-vest-top-hair-bag-and-more/1326317
Read the cfx.re post for more information!
